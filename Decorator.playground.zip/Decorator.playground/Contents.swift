

protocol Posche {
    func getPrice() -> Double
    func getDescription() -> String
}

class Boxter: Posche {
    func getPrice() -> Double {
        return 120
    }
    
    func getDescription() -> String {
        return "Porsche Boxter"
    }
}


class PorscheDecorator: Posche {
    
    private let decoratedPorsche: Posche
    
    required init(dp: Posche) {
        self.decoratedPorsche = dp
    }
    
    func getPrice() -> Double {
        return decoratedPorsche.getPrice()
    }
    
    func getDescription() -> String {
        return decoratedPorsche.getDescription()
    }
}


class PremiumAudioSystem: PorscheDecorator {
   
    required init(dp: Posche) {
        super.init(dp: dp)
    }
    
    override func getPrice() -> Double {
        return super.getPrice() + 30
    }
    
    override func getDescription() -> String {
        return super.getDescription() + " + Premium Audio"
    }
}

class PanoramicSunruof: PorscheDecorator {
    
    required init(dp: Posche) {
        super .init(dp: dp)
    }
    
    override func getPrice() -> Double {
        return super.getPrice() + 20
    }
    
    override func getDescription() -> String {
        return super.getDescription() + " + Paniramic Sunfouf"
    }
}


var porscheBoxter: Posche = Boxter()
porscheBoxter.getDescription()
porscheBoxter.getPrice()

porscheBoxter = PremiumAudioSystem(dp: porscheBoxter)
porscheBoxter.getDescription()
porscheBoxter.getPrice()

porscheBoxter = PanoramicSunruof(dp: porscheBoxter)
porscheBoxter.getDescription()
porscheBoxter.getPrice()
