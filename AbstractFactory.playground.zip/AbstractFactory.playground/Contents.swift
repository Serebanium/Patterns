


protocol Car {
    func drive()
}



class LittleSizeCar: Car {
    func drive() {
        print("drive a little car")
    }
}



class MiddleSizeCar: Car {
    func drive() {
        print("drive a middle car")
    }
}



protocol Bus {
    func drive()
}



class LittleSizeBus: Bus {
    func drive() {
        print("drive a little bus")
    }
}



class MiddleSizeBus: Bus {
    func drive() {
        print("drive a middle bus")
    }
}



protocol Factory {
    func proruceBus() -> Bus
    func proruceCar() -> Car
}



class LittleSizeFactory: Factory {
    func proruceBus() -> Bus {
        print("little bus is created")
        return LittleSizeBus()
    }
    
    func proruceCar() -> Car {
        print("little car is created")
        return LittleSizeCar()
    }
}


class MiddleSizeFactory: Factory {
    func proruceBus() -> Bus {
        print("Middle bus is created")
        return MiddleSizeBus()
    }
    
    func proruceCar() -> Car {
        print("Middle car is created")
        return MiddleSizeCar()
    }
}



let littleFactory = LittleSizeFactory()
let littleBus = littleFactory.proruceBus()
littleBus.drive()
