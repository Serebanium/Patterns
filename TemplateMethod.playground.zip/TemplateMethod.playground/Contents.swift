


protocol DriveVehicle {
    
    func haveASeat()
    func closeTheDoor()
    func useProtection()
    func lookAtAMirror()
    func turnSignal()
    func driveForvard()
    
    func startVehicle()
}

extension DriveVehicle {
    
    func haveASeat() {
        preconditionFailure("this method should be overriden")
    }
    
    func closeTheDoor() {
    }
    
    func useProtection() {
        preconditionFailure("this method should be overriden")
    }
    
    func lookAtAMirror() {
        preconditionFailure("this method should be overriden")
    }
    
    func turnSignal() {
        preconditionFailure("this method should be overriden")
    }
    
    func driveForvard() {
        preconditionFailure("this method should be overriden")
    }
    
    func startVehicle() {
        haveASeat()
        closeTheDoor()
        useProtection()
        lookAtAMirror()
        turnSignal()
        driveForvard()
    }
}


class Bicycle: DriveVehicle {
    func haveASeat() {
        print("sit down on a bicycle seat")
    }
    
    func useProtection() {
       print("wear a helmet")
    }
    
    func lookAtAMirror() {
        print("look at a little mirror")
    }
    
    func turnSignal() {
        print("show left hand")
    }
    
    func driveForvard() {
        print("pedal")
    }
}

class Car: DriveVehicle {
    func haveASeat() {
        print("sit down on a car seat")
    }
    
    func closeTheDoor() {
        print("close the door")
    }
    
    func useProtection() {
        print("fasten seat belt")
    }
    
    func lookAtAMirror() {
        print("look at a mirror")
    }
    
    func turnSignal() {
        print("turn on left turn light")
    }
    
    func driveForvard() {
        print("gas")
    }
}

let car = Car()
let bycycle = Bicycle()

car.startVehicle()
print(" ")
bycycle.startVehicle()
