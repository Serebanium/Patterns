

//adaptee

class SimpleCar {
    func sound() -> String {
        return "tr-tr-tr"
    }
}


// target
protocol SupercarProtocol {
    func makeNoise() -> String
}


class Supercar: SupercarProtocol {
    func makeNoise() -> String {
        return "wroom-wroom"
    }
}


// adapter
class SuperCarAdapter: SupercarProtocol {
    var simpleCar: SimpleCar
    
    func makeNoise() -> String {
        return simpleCar.sound()
    }
    
    init(simpleCar: SimpleCar) {
        self.simpleCar = simpleCar
    }
}



let car = SimpleCar()

SuperCarAdapter(simpleCar: car).makeNoise()
