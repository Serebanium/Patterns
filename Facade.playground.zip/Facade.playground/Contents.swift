

class FruitShop {
    func buyFruits() -> String {
        return "Fruits "
    }
}


class MeatShop {
    func buyMeat() -> String {
        return "Meat "
    }
}


class MilkShop {
    func buyMilk() -> String {
        return "Milk "
    }
}


// можно так
class Supermarket {
    let fruitShop: FruitShop
    let meatShop: MeatShop
    let milkShop: MilkShop
    
    func bueAll() -> String {
        return fruitShop.buyFruits() + meatShop.buyMeat() + milkShop.buyMilk()
    }
    
    init(fruitShop: FruitShop, meatShop: MeatShop, milkShop: MilkShop) {
        self.fruitShop = fruitShop
        self.meatShop = meatShop
        self.milkShop = milkShop
    }
}

// а можно так
class Supermarket_2 {
    let fruitShop = FruitShop()
    let meatShop = MeatShop()
    let milkShop = MilkShop()
    
    func bueAll() -> String {
        return fruitShop.buyFruits() + meatShop.buyMeat() + milkShop.buyMilk()
    }
}


let supermarket = Supermarket(fruitShop: FruitShop(), meatShop: MeatShop(), milkShop: MilkShop())
supermarket.bueAll()

let supermarket_2 = Supermarket_2()
supermarket_2.bueAll()
