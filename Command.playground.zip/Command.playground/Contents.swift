

class Account {
    var accountName: String = ""
    var balance: Int
    
    init(accountName: String, balance: Int) {
        self.accountName = accountName
        self.balance = balance
    }
}



protocol Command {
    func execute()
    var isComplite: Bool { get set }
}



class Deposite: Command {
    
    private var _account: Account
    private var _amount: Int
    var isComplite = false
    
    func execute() {
        _account.balance += _amount
        isComplite = true
        print("Пополнено \(_amount), баланс \(_account.balance)")
    }
    
    init(account: Account, amount: Int) {
        self._account = account
        self._amount = amount
    }
}



class Withdraw: Command {
    
    private var _account: Account
    private var _amount: Int
    var isComplite = false
    
    func execute() {
        if _account.balance >= _amount {
            _account.balance -= _amount
            isComplite = true
            print("Снято \(_amount), баланс \(_account.balance)")
        } else {
            print("Недостаточно денег")
        }
    }
    
    init(account: Account, amount: Int) {
        self._account = account
        self._amount = amount
    }
}



class TransactionManager {
    static let shared = TransactionManager()
    private init() {}
    private var _transactions: [Command] = []
    
    var pendingTransaction: [Command] {
        get {
            return self._transactions.filter{ $0.isComplite == false }
        }
    }
    
    func addTransactions(command: Command) {
        self._transactions.append(command)
    }
    
    func processingTransactions() {
        _transactions.filter{ $0.isComplite == false }.forEach{ $0.execute() }
    }
}


let account = Account(accountName: "Sergey", balance: 1000)
let transactionManager = TransactionManager.shared
transactionManager.addTransactions(command: Deposite(account: account, amount: 100))
transactionManager.addTransactions(command: Withdraw(account: account, amount: 10))
transactionManager.processingTransactions()
