

//class User {
//    let id = "123"
//}
//
//protocol ServerProtocol {
//    func grantAccess(user: User)
//    func denyAccess(user: User)
//}
//
//class SerwerSide: ServerProtocol {
//    func grantAccess(user: User) {
//        print("доступ предоставлен пользователю ID \(user.id)")
//    }
//
//    func denyAccess(user: User) {
//        print("в доступе отказано пользователю ID \(user.id)")
//    }
//}
//
//class SerwerProxy: ServerProtocol {
//    lazy private var server: SerwerSide = SerwerSide()
//
//    func grantAccess(user: User) {
//        server.grandAccess(user: user)
//    }
//
//    func denyAccess(user: User) {
//        server.denyAccess(user: user)
//    }
//}
//
//
//let user = User()
//let proxy = SerwerProxy()
//
//proxy.grantAccess(user: user)
//proxy.denyAccess(user: user)


class User {
    let name = "Петя"
    let password = "123"
}

protocol ServerProtocol {
    func grantAccess(user: User)
   // func denyAccess(user: User)
}

class ServerSide: ServerProtocol {
    func grantAccess(user: User) {
        print("доступ предоставлен пользователю \(user.name)")
    }
}

class ServerProxy: ServerProtocol {
    private var server: ServerSide!
    
    func grantAccess(user: User) {
        guard server != nil else {
            print("пользователю \(user.name) в доступе отказано")
            return
        }
        server.grantAccess(user: user)
    }
    
    func authenticate(user: User) {
        guard user.password == "123" else { return }
        print("Пользователь \(user.name) авторизован")
        server = ServerSide()
    }
}

let user = User()
let proxy = ServerProxy()

proxy.grantAccess(user: user)
proxy.authenticate(user: user)
proxy.grantAccess(user: user)
