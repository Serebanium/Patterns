

class Driver {
    let isGoodDriver: Bool
    let name: String
    
    init(isGoodDriver: Bool, name: String) {
        self.isGoodDriver = isGoodDriver
        self.name = name
    }
}

protocol BasicIterator: IteratorProtocol {
    init(drivers: [Driver])
    func allDrivers() -> [Driver]
}

class GoodDriverIterator: BasicIterator {
    private let drivers: [Driver]
    private var current = 0
    
    required init(drivers: [Driver]) {
        self.drivers = drivers.filter{ $0.isGoodDriver }
    }
    
    func next() -> Driver? {
        defer { current += 1 }
        return drivers.count > current ? drivers[current] : nil
    }
    
    func allDrivers() -> [Driver] {
        return drivers
    }
}

class BadDriverIterator: BasicIterator {
    private let drivers: [Driver]
    private var current = 0
    
    required init(drivers: [Driver]) {
        self.drivers = drivers.filter{ !$0.isGoodDriver }
    }
    
    func next() -> Driver? {
        defer { current += 1 }
        return drivers.count > current ? drivers[current] : nil
    }
    
    func allDrivers() -> [Driver] {
        return drivers
    }
}

class AllDriverIterator: BasicIterator {
    private let drivers: [Driver]
    private var current = 0
    
    required init(drivers: [Driver]) {
        self.drivers = drivers
    }
    
   func next() -> Driver? {
    defer { current += 1 }
    return drivers.count > current ? drivers[current] : nil
    }
    
    func allDrivers() -> [Driver] {
        return drivers
    }
}

class Car {
    
    private let drivers =
        [
            Driver(isGoodDriver: true, name: "Mark"),
            Driver(isGoodDriver: false, name: "Ivan"),
            Driver(isGoodDriver: true, name: "Maria"),
            Driver(isGoodDriver: false, name: "Morgan"),
        ]
    
    var goodDriverIterator: GoodDriverIterator {
        return GoodDriverIterator(drivers: drivers)
    }
    
    var badDriverIterator: BadDriverIterator {
        return BadDriverIterator(drivers: drivers)
    }
}

extension Car: Sequence {
    func makeIterator() -> GoodDriverIterator {
        return GoodDriverIterator(drivers: drivers)
    }
}


let car = Car()
let goodDriverIterator = car.goodDriverIterator.next()

let goodDriverIterator2 = car.makeIterator().allDrivers()

let badDriverIterator = car.badDriverIterator.allDrivers()

for driver in car {
    print(driver.name)
}
