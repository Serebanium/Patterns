

class Enemy {
    let strenght = 600
}

protocol MilitaryChain {
    var strenght: Int { get }
    var nextRank: MilitaryChain? { get set }
    func shouldDefeatWithStrenhth(amount: Int)
}

class Soldier: MilitaryChain {
    var strenght = 100
    
    var nextRank: MilitaryChain?
    
    func shouldDefeatWithStrenhth(amount: Int) {
        if amount < strenght {
            print("Солдат победил")
        } else {
            print("Солдат не смог победить")
            nextRank?.shouldDefeatWithStrenhth(amount: amount)
        }
    }
}

class Officer: MilitaryChain {
    var strenght = 500
    
    var nextRank: MilitaryChain?
    
    func shouldDefeatWithStrenhth(amount: Int) {
        if amount < strenght {
            print("Офицер победил")
        } else {
            print("Офицер не смог победить")
            nextRank?.shouldDefeatWithStrenhth(amount: amount)
        }
    }
}

class General: MilitaryChain {
    var strenght = 1000
    
    var nextRank: MilitaryChain?
    
    func shouldDefeatWithStrenhth(amount: Int) {
        if amount < strenght {
            print("Генерал победил")
        } else {
            print("Никто не сумел победить льва")
        }
    }
}


let enemy = Enemy()
let solder = Soldier()
let officer = Officer()
let general = General()

solder.nextRank = officer
officer.nextRank = general

solder.shouldDefeatWithStrenhth(amount: enemy.strenght)
