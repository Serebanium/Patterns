//
//  ViewController.swift
//  Singleton
//
//  Created by Сергей Иванов on 04/07/2019.
//  Copyright © 2019 topMob. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let safe = Safe.shared
        print(safe.money)
    }


}

