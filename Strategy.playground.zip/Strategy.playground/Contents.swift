

protocol SwimBehavior {
    func swim()
}

class ProfessionalSwimmer: SwimBehavior {
    func swim() {
        print("professional swimming")
    }
}

class NewbieSwimmer: SwimBehavior {
    func swim() {
        print("newbie swimming")
    }
}

class NonSwimmer: SwimBehavior {
    func swim() {
        print("non-swimming")
    }
}

protocol DiveBehavior {
    func dive()
}

class ProfessionalDiver: DiveBehavior {
    func dive() {
        print("professional diving")
    }
}

class NewbieDiver: DiveBehavior {
    func dive() {
        print("newbie diving")
    }
}

class NonDiver: DiveBehavior {
    func dive() {
        print("non-diving")
    }
}

class Human {
    
    private var diveBihavior: DiveBehavior!
    private var swimBihavior: SwimBehavior!
    
    func performSwim() {
        swimBihavior.swim()
    }
    
    func performDive() {
        diveBihavior.dive()
    }
    
    func setSwimBehavior(sb: SwimBehavior) {
        self.swimBihavior = sb
    }
    
    func setDiveBihavior(db: DiveBehavior) {
        self.diveBihavior = db
    }
    
    func run() {
        print("runing")
    }
    
    init(swimBihavior: SwimBehavior, diveBihavior: DiveBehavior) {
        self.swimBihavior = swimBihavior
        self.diveBihavior = diveBihavior
    }
}

let human = Human(swimBihavior: ProfessionalSwimmer(), diveBihavior: ProfessionalDiver())

//human.setDiveBihavior(db: ProfessionalDiver())
human.performDive()
human.setSwimBehavior(sb: NonSwimmer())
human.performSwim()
