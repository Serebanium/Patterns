protocol State {
    func on(printer: Printer)
    func off(printer: Printer)
    func printDoc(printer: Printer)
}

class On: State {
    func on(printer: Printer) {
        print("!!! Принтер уже включен !!!")
    }
    
    func off(printer: Printer) {
        print("Отключаю принтер")
        printer.set(state: Off())
    }
    
    func printDoc(printer: Printer) {
        print("Отправляю на печать")
        printer.set(state: Print())
    }
}

class Off: State {
    func on(printer: Printer) {
        print("Включаю принтер")
        printer.set(state: On())
    }
    
    func off(printer: Printer) {
        print("!!! Принтер уже отключен !!!")
    }
    
    func printDoc(printer: Printer) {
        print("!!! Принтер отключен !!!")
    }
}

class Print: State {
    func on(printer: Printer) {
        print("!!! Принтер уже включен !!!")
    }
    
    func off(printer: Printer) {
        print("Отключаю принтер")
        printer.set(state: Off())
    }
    
    func printDoc(printer: Printer) {
        print("!!! Принтер занят !!!")
    }
}

class Printer {
    var state: State
    
    init() {
        self.state = On()
    }
    
    func set(state: State) {
        self.state = state
    }
    
    func turnOn() {
        state.on(printer: self)
    }
    
    func turnOff() {
        state.off(printer: self)
    }
    
    func turnPrint() {
        state.printDoc(printer: self)
    }
}

var printer = Printer()

printer.turnOn()
printer.turnPrint()
printer.turnPrint()
printer.turnOff()
printer.turnOff()
printer.turnPrint()
printer.turnOn()
